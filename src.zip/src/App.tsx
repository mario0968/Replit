import HeaderSection from "./components/sections/HeaderSection";
import { BuyWithCardModalTarget } from "./components/BuyWithCardModal";
import { ConnectWalletModalTarget } from "./components/ConnectWalletModal";

function App() {
  return (
    <>
      <main id="main" className="flex min-h-screen flex-col app-bg bg-noise">
        <HeaderSection />
        <BuyWithCardModalTarget />
        <ConnectWalletModalTarget />
      </main>
    </>
  );
}

export default App;
